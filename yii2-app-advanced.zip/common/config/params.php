<?php

return [
    
    'name' => 'DRIVESOURCE.C/O',
    'modifyby' => 'DRIVESOURCE.C/O',
    
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600
    
];